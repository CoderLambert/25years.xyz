#!/bin/bash

# build the symlink to require-css. done by script as it breaks project builds
cd www
ln -s ../../ require-css
