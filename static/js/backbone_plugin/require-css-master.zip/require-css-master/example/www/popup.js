define(['css!popup'], function() {
  return "<div class='popup'>popup content</div>";
});
